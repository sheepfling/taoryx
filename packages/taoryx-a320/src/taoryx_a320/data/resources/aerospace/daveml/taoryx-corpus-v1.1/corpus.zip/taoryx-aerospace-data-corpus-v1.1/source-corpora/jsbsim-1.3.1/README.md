# JSBSim model corpus

Pinned source: `v1.3.1` / `3b25f25e49b42d0489c04ac805674fc1450ca579`.

- `raw/`: exact selected upstream aircraft, engine, system, and script files (487 files).
- `normalized-models/`: normalized IR for all 64 loadable configurations.
- `catalog/`: original catalog export.
- `normalized-export-status.csv`: per-model extraction status; all models exported successfully.
- `jsbsim-v1.3.1-model-data.tar.xz`: compact raw-source convenience archive.

Use raw XML as the semantic authority and normalized files as query/ingestion aids.
