
# Licensing and provenance

This corpus preserves source-specific notices instead of applying one blanket license to all data.

- JSBSim: see `source-corpora/jsbsim-1.3.1/raw/COPYING`, source metadata, file inventory, and file hashes.
- OpenAP A320 source records: see `qualified-models/a320-openap/source/openap/data/LICENSE`.
- F-16 S-119, NASA/NESC rocket, and HL-20: see their included source files, provenance JSON, model documentation, and evidence bundles.
- Taoryx ingestion/runtime tooling: see the source release and its project metadata under `releases/`.

Before redistributing a subset outside this handoff, carry forward the relevant notices and provenance. Model-data availability does not imply manufacturer endorsement, certification suitability, or unrestricted relicensing.
