# Where the backing data is

## F-16

The highest-confidence Taoryx baseline is under:

```text
qualified-models/f16-s119/
```

That directory contains the normalized DAVE-ML aerodynamic, propulsion, and inertia sources; direct-control
binding; runtime binding; `.txair`; trim result; point evaluation; verification report; and rigid-body hold.

The independent JSBSim F-16 source candidate is also included:

```text
source-corpora/jsbsim-1.3.1/raw/aircraft/f16/
source-corpora/jsbsim-1.3.1/normalized-models/f16/f16/
```

These are separate model lineages and should not be mixed without an explicit fusion contract.

## HL-20

The exact pinned Mod K DAVE-ML source and all normalized data are under:

```text
qualified-models/hl20-mod-k/source/aerodynamics.dml
qualified-models/hl20-mod-k/source-ir/
qualified-models/hl20-mod-k/tables/
qualified-models/hl20-mod-k/validation/
qualified-models/hl20-mod-k/taoryx-hl20-mod-k-unpowered-v0.10.txair
```

The source IR includes every variable, breakpoint, function, MathML expression, gridded table point, check case,
and provenance record from the accepted source.

## A320

There are two complementary A320 data lineages.

### Qualified 3-DOF performance model: OpenAP

```text
qualified-models/a320-openap/source/openap/data/
qualified-models/a320-openap/runtime/openap-a320.json
qualified-models/a320-openap/tables/
qualified-models/a320-openap/validation/
qualified-models/a320-openap/taoryx-a320-openap-2.6-v0.8.txair
```

This is the baseline for drag, thrust, fuel flow, mass limits, and mission performance.

### Six-axis surrogate source: JSBSim

```text
source-corpora/jsbsim-1.3.1/raw/aircraft/A320/
source-corpora/jsbsim-1.3.1/raw/engine/CFM56_5.xml
source-corpora/jsbsim-1.3.1/raw/engine/direct.xml
source-corpora/jsbsim-1.3.1/normalized-models/A320/A320/
consolidated/a320-jsbsim-summary.json
```

Use OpenAP for the translational performance backbone and JSBSim only as an explicitly lower-confidence source
for moments, stability derivatives, controls, and initial inertia when building a pseudo-6DOF surrogate.

## Every other catalog vehicle

Find the vehicle in:

```text
consolidated/model-catalog.csv
```

The `model_key` maps directly to:

```text
source-corpora/jsbsim-1.3.1/normalized-models/<model_key>/
```

The `source_path` column maps to the exact raw XML under:

```text
source-corpora/jsbsim-1.3.1/raw/
```

Referenced engines and thrusters are named in the catalog columns `engine_files` and `thruster_files` and are
stored under `source-corpora/jsbsim-1.3.1/raw/engine/` unless an aircraft-local dependency is used.

## Corpus-wide query files

```text
consolidated/all-aerodynamic-functions.csv
consolidated/all-aerodynamic-table-points.csv
consolidated/all-propulsion-table-points.csv
consolidated/all-quantities.csv
```

These combine all 64 normalized configurations and include `model_key` on every row.
