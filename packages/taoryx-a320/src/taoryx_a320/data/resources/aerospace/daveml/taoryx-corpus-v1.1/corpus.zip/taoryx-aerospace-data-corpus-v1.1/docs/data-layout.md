
# Data layout

## `qualified-models/`

Curated Taoryx packages and their complete evidence. These are the first-line regression baselines.

## `source-corpora/jsbsim-1.3.1/raw/`

Pinned, unmodified model data: aircraft XML, engines, thrusters, systems, scripts, MATLAB support, source metadata, inventory, hashes, and the project copying notice.

## `source-corpora/jsbsim-1.3.1/normalized-models/`

Loss-preserving exports produced by the Taoryx ingestion tooling. Each directory is keyed by the catalog's `model_key` and carries quantities, functions, expression trees, aerodynamic table points, propulsion table points, and a model summary.

## `consolidated/`

Flat corpus-wide CSV/JSON files for search, analysis, and bulk import. Every row carries a model key so the original model boundary is recoverable.

## `focus-vehicles/`

Navigation-only indexes for F-16, A320, and HL-20. The source of truth remains in the qualified model and source-corpus directories referenced there.

## `releases/`

Original versioned evidence bundles and the v0.10 ingestion/runtime tooling release. These are retained so the consolidated corpus does not erase release provenance.
