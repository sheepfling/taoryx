
# Taoryx Aerospace Data Corpus v1.1

This is the complete offline data handoff assembled for the Taoryx aerodynamic and flight-dynamics testing baseline.

It contains four qualified Taoryx runtime packages plus the full pinned JSBSim 1.3.1 model-data corpus in both raw and normalized forms. The JSBSim collection contains **64 loadable configurations**, **59 with all six aerodynamic axes present**, **1,799 aerodynamic functions**, **644 aerodynamic tables / 14,303 points**, and **147 propulsion tables / 8,929 points**.

## Start here

- `consolidated/qualified-model-index.csv` — the four qualified Taoryx packages.
- `consolidated/model-catalog.csv` — all 64 JSBSim configurations and coverage counts.
- `consolidated/vehicle-paths.json` — direct path map for F-16, A320, HL-20, and the complete catalog.
- `focus-vehicles/` — short navigation guides for the three vehicles you asked for explicitly.
- `source-corpora/jsbsim-1.3.1/raw/` — original aircraft, engine, system, script, and related source files.
- `source-corpora/jsbsim-1.3.1/normalized-models/` — one normalized IR directory per catalog configuration.
- `consolidated/all-*.csv` — corpus-wide flat tables for analytics and ingestion.
- `releases/` — original evidence bundles, source release, wheel, and release manifests.

## Qualified Taoryx models

| Model ID | Vehicle | Fidelity | Runtime package | Qualification |
|---|---|---|---|---|
| `f16-s119-reference` | F-16 | `6dof` | `qualified-models/f16-s119/taoryx-f16-s119-reference-v0.7.txair` | 29 component checks + trim + rigid-body hold |
| `a320-openap-2.6` | Airbus A320 | `3dof` | `qualified-models/a320-openap/taoryx-a320-openap-2.6-v0.8.txair` | 272/272 OpenAP oracle comparisons |
| `nesc-two-stage-rocket` | NASA/NESC two-stage rocket | `6dof-variable-mass` | `qualified-models/nesc-two-stage-rocket/taoryx-nesc-two-stage-rocket-v0.9.txair` | source checks + event/mass checks + trajectory convergence |
| `hl20-mod-k-unpowered` | NASA HL-20 | `6dof-unpowered` | `qualified-models/hl20-mod-k/taoryx-hl20-mod-k-unpowered-v0.10.txair` | 24/24 embedded checks + glide trim + rigid-body hold |

## What “all data” means here

For every JSBSim configuration, the corpus includes the raw source and dependencies plus:

```text
model.json
quantities.csv
aerodynamic-functions.csv
aerodynamic-expressions.json
aerodynamic-tables.csv
propulsion-tables.csv
table-index.json
```

The four qualified vehicles additionally include source records, runtime specifications, validation vectors, trims, trajectories, provenance, checksums, schemas, evidence, and compiled `.txair` packages.

## Qualification boundary

The 64 JSBSim exports are **source-corpus models**, not 64 qualified Taoryx models. Structural completeness means the requested axes/functions are present; it does not imply manufacturer validation or high-fidelity agreement. The four entries in `qualified-model-index.csv` are the models that have explicit Taoryx packaging and acceptance evidence in this handoff.

## Verification

Run with Python 3.12+; no third-party packages are required:

```bash
python scripts/verify_corpus.py --root .
```

The verifier checks the file inventory, SHA-256 ledger, catalog/export counts, normalized-model directories, required focus-vehicle paths, and internal ZIP/`.txair` CRC integrity.

## Catalog configurations

- `737/737` — 737
- `787-8/787-8` — 787-8
- `A320/A320` — A320-200
- `A4/A4` — A-4
- `ah1s/ah1s` — ah1s-jsbsim
- `B17/B17` — Boeing B-17G
- `B747/B747` — B747-400
- `ball/ball` — BALL
- `ballx/ballx` — BALLX
- `Boeing314/Boeing314` — Boeing314A
- `C130/C130` — C130
- `c172p/c172p` — c172
- `c172r/c172r` — c172
- `c172x/c172x` — Cessna C-172 Skyhawk II
- `c182/c182` — c182
- `c310/c310` — Cessna 310 Light Twin General Aviation Aircraft
- `Camel/Camel` — Sopwith Camel
- `Concorde/Concorde` — Aerospatiale/BAC Concorde
- `DHC6/DHC6` — DHC-6
- `dr1/dr1` — Fokker Dr.1
- `f104/f104` — F-104C
- `f15/f15` — f15
- `f16/f16` — General Dynamics F-16A
- `f22/f22` — General Dynamics F-22A
- `f22/yf22` — F22
- `F450/F450` — F450
- `F4N/F4N-jsbsim` — F4N
- `F4N/F4N` — F4N
- `F80C/F80C` — F80C
- `fokker100/fokker100` — Fokker-100
- `fokker100/fokker70` — Fokker 70
- `fokker100/xf100` — Fokker-100
- `fokker50/fokker50` — fokker50
- `global5000/global5000` — global5000
- `J246/J246` — Jupiter-246 - Lunar Crew Launch Vehicle Configuration
- `J3Cub/J3Cub` — J3Cub
- `L17/L17` — Navion
- `L410/L410` — Czech Republic LET 410 Light Twin
- `MD11/MD11` — MD11
- `minisgs/minisgs` — sgstest
- `mk82/mk82` — MK-82
- `OV10/OV10` — OV10 Bronco
- `p51d/p51d` — P-51D (JSBSim)
- `pa28/pa28` — PA28-180
- `paraglider/paraglider` — paraglider
- `pc7/pc7` — PC-7
- `pogo-jsbsim/pogo-jsbsim` — Pogo
- `Pterosaur/Pterosaur` — Pterosaur
- `SGS/SGS` — sgstest
- `sgs126/sgs126` — sgs126
- `sgs233/sgs233` — sgs233
- `Short_S23/Short_S23` — Short S.23
- `Shuttle/Shuttle` — Space Shuttle
- `Submarine_Scout/Submarine_Scout` — SubmarineScout
- `T37/T37` — T37
- `T38/T38` — T38
- `t6texan2/t6texan2` — T62
- `weather-balloon/weather-balloon` — Weather Balloon
- `wrightFlyer1903/wrightFlyer1903` — wrightFlyer1903
- `wrightFlyer1903/wrightFlyer1905` — wrightFlyer1903
- `X15/X15` — North American X-15
- `x24b/x24b` — X-24B
- `XB-70/XB-70` — XB-70
- `ZLT-NT/ZLT-NT` — NT07
