# Airbus A320 OpenAP 2.6 Point-Mass Model

This package is a deterministic three-degree-of-freedom point-mass performance model compiled from OpenAP 2.6.0 for the A320 using the CFM56-5B4 default engine.

## Included behavior

- clean quadratic drag polar;
- flap and discrete landing-gear drag increments;
- maximum takeoff, climb, and cruise thrust;
- descent-idle thrust approximation;
- fuel flow versus total aircraft thrust;
- published scalar mass and geometry limits;
- generated SI drag, thrust, fuel, and steady-level performance tables.

## Reference cruise

At 60,000 kg, 11,000 m, and Mach 0.78, the compiled model requires 32807.716586 N of thrust and 0.696755123 kg/s of fuel flow. The selected maximum-cruise thrust is 44606.053202 N.

## Important boundaries

- This is not a rigid-body 6-DOF model.
- Center of gravity and inertia tensor are unavailable.
- Wave drag is disabled because the upstream option is experimental.
- The 0-to-1 throttle mapping is a Taoryx linear binding between OpenAP idle and the selected maximum-thrust regime.
- OpenAP source data under `source/openap/` retain their GNU GPL v3 license.
- Generated tables preserve provenance but are not certification data.
