# Taoryx A320 OpenAP 2.6 evidence bundle

This directory contains the complete inspectable evidence for the v0.8 A320 point-mass package.

Included:

- standalone `a320-openap-2.6-v0.8.txair`;
- exact OpenAP data source records and license;
- compiled runtime specification;
- 950 normalized CSV table rows;
- 272-case oracle comparison report;
- reference cruise result;
- clean-wheel runtime and oracle smoke results;
- JSON Schemas;
- package manifest, quality report, and hashes.

The model is 3-DOF point-mass performance data. It does not contain body moments, CG, or an inertia tensor.
