
# A320 data map

The A320 data are intentionally split by purpose:

1. `qualified-models/a320-openap/` contains the qualified OpenAP 2.6.0 point-mass package: exact A320/CFM56-5B4 source records, clean/configured drag, takeoff/climb/cruise/descent thrust, fuel flow, scalar mass data, validation, and the compiled 3-DOF `.txair` package.
2. `source-corpora/jsbsim-1.3.1/raw/aircraft/A320/` contains the JSBSim A320-200 six-axis approximation.
3. `source-corpora/jsbsim-1.3.1/raw/engine/CFM56_5.xml` and `raw/engine/direct.xml` are its propulsion dependencies.
4. `source-corpora/jsbsim-1.3.1/normalized-models/A320/A320/` contains the normalized aerodynamic functions, table points, quantities, expressions, and propulsion maps.

For a pseudo-6DOF Taoryx model, preserve OpenAP as the translational performance source and use the JSBSim model only as an explicitly approximate source of rotational/control structure. Do not add overlapping drag or thrust contributions from both models.
