
from __future__ import annotations

import argparse
import csv
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, default=Path('.'))
    parser.add_argument('--six-axis-only', action='store_true')
    args = parser.parse_args()
    path = args.root / 'consolidated/model-catalog.csv'
    with path.open(newline='', encoding='utf-8') as f:
        rows = list(csv.DictReader(f))
    for row in rows:
        if args.six_axis_only and row['six_axis_complete'].lower() != 'true':
            continue
        print(
            f"{row['model_key']:<36} {row['name']:<32} "
            f"axes={row['axes']} aero_points={row['aerodynamic_point_count']} "
            f"prop_points={row['propulsion_point_count']}"
        )
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
