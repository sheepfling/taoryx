
# Taoryx ingestion map

## Direct regression baselines

Load the `.txair` files named by `consolidated/qualified-model-index.csv`.

## Bulk JSBSim analysis

Use `consolidated/model-catalog.csv` to select model keys, then load the corresponding directory under `source-corpora/jsbsim-1.3.1/normalized-models/<model_key>/`.

Recommended order:

1. Read `model.json` for source identity, axes, dependencies, and counts.
2. Read `quantities.csv` for geometry, mass properties, limits, and source constants.
3. Read `aerodynamic-functions.csv` and `aerodynamic-expressions.json` together.
4. Read `aerodynamic-tables.csv` and `table-index.json` for coefficient maps and dimension order.
5. Read `propulsion-tables.csv` for engine/thruster maps.
6. Keep raw source paths and SHA-256 values attached to any compiled Taoryx artifact.

The consolidated CSVs are optimized for corpus mining; the per-model directories are the safer compilation input because they preserve model boundaries and expression context.
