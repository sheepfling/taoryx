# JSBSim 1.3.1 offline aircraft-model catalog

This catalog was generated from the data root bundled with the JSBSim 1.3.1 Python package using Taoryx aircraft-model tooling v0.3.

Measured coverage in this exact bundle:

```text
loadable configurations:          64
complete six-axis configurations: 59
aerodynamic functions:         1,799
aerodynamic tables:              644
aerodynamic points:           14,303
propulsion tables:               147
propulsion points:             8,929
models with parser issues:          0
```

`catalog.csv` is intended for filtering and model selection. `catalog.json` retains the complete typed inventory.

Counts are version-specific. Individual model quality, provenance, and licensing must be reviewed before use.
