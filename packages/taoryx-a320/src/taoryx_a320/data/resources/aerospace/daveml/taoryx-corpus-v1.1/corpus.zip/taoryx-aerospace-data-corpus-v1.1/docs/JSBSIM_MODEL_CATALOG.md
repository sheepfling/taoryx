# JSBSim 1.3.1 vehicle catalog

This table lists all 64 normalized configurations included in the corpus.

| Model key | Name | Axes | Six-axis | Aero points | Propulsion points | Engines | Upstream release |
|---|---|---|:---:|---:|---:|---|---|
| 737/737 | 737 | DRAG, SIDE, LIFT, ROLL, PITCH, YAW | yes | 49 | 104 | CFM56 | BETA |
| 787-8/787-8 | 787-8 | LIFT, DRAG, SIDE, ROLL, PITCH, YAW | yes | 31 | 112 | trent_1000 | BETA |
| A320/A320 | A320-200 | DRAG, SIDE, LIFT, ROLL, PITCH, YAW | yes | 197 | 104 | CFM56_5 | BETA |
| A4/A4 | A-4 | LIFT, DRAG, SIDE, ROLL, PITCH, YAW | yes | 22 | 112 | J52 | ALPHA |
| ah1s/ah1s | ah1s-jsbsim | LIFT, DRAG, SIDE, PITCH, YAW | no | 132 | 0 | electric_1500hp, electric_1hp_dummy | ALPHA |
| B17/B17 | Boeing B-17G | LIFT, DRAG, SIDE, ROLL, PITCH, YAW | yes | 22 | 68 | R-1820-97 | ALPHA |
| B747/B747 | B747-400 | DRAG, SIDE, LIFT, ROLL, PITCH, YAW | yes | 22 | 112 | GE-CF6-80C2-B1F | ALPHA |
| ball/ball | BALL | DRAG | no | 0 | 0 | — | BETA |
| ballx/ballx | BALLX | DRAG | no | 57 | 0 | — | BETA |
| Boeing314/Boeing314 | Boeing314A | DRAG, SIDE, LIFT, ROLL, PITCH, YAW | yes | 342 | 64 | WrightGR-2600 | PRODUCTION |
| C130/C130 | C130 | DRAG, SIDE, LIFT, ROLL, PITCH, YAW | yes | 22 | 140 | t56 | BETA |
| c172p/c172p | c172 | DRAG, SIDE, LIFT, ROLL, PITCH, YAW | yes | 200 | 56 | eng_io320 | BETA |
| c172r/c172r | c172 | DRAG, SIDE, LIFT, ROLL, PITCH, YAW | yes | 187 | 14 | engIO360C | BETA |
| c172x/c172x | Cessna C-172 Skyhawk II | LIFT, DRAG, SIDE, ROLL, PITCH, YAW | yes | 2098 | 56 | eng_io320 | BETA |
| c182/c182 | c182 | DRAG, SIDE, LIFT, ROLL, PITCH, YAW | yes | 194 | 212 | engIO540AB1A5 | BETA |
| c310/c310 | Cessna 310 Light Twin General Aviation Aircraft | DRAG, SIDE, LIFT, ROLL, PITCH, YAW | yes | 99 | 380 | engIO470D | BETA |
| Camel/Camel | Sopwith Camel | LIFT, DRAG, SIDE, ROLL, PITCH, YAW | yes | 1265 | 47 | Clerget9B | ALPHA |
| Concorde/Concorde | Aerospatiale/BAC Concorde | DRAG, SIDE, LIFT, ROLL, PITCH, YAW | yes | 79 | 684 | Olympus593Mrk610 | PRODUCTION |
| DHC6/DHC6 | DHC-6 | DRAG, SIDE, LIFT, ROLL, PITCH, YAW | yes | 479 | 569 | PT6A-27 | BETA |
| dr1/dr1 | Fokker Dr.1 | LIFT, DRAG, SIDE, ROLL, PITCH, YAW | yes | 394 | 50 | Oberursel-UrII | ALPHA |
| f104/f104 | F-104C | LIFT, DRAG, SIDE, ROLL, PITCH, YAW | yes | 215 | 224 | J79-GE-11A | ALPHA |
| f15/f15 | f15 | DRAG, SIDE, LIFT, ROLL, PITCH, YAW | yes | 166 | 224 | F100-PW-229 | BETA |
| f16/f16 | General Dynamics F-16A | DRAG, SIDE, LIFT, ROLL, PITCH, YAW | yes | 1074 | 224 | F100-PW-229 | PRODUCTION |
| f22/f22 | General Dynamics F-22A | DRAG, SIDE, LIFT, ROLL, PITCH, YAW | yes | 346 | 308 | F119-PW-1 | PRODUCTION |
| f22/yf22 | F22 | DRAG, SIDE, LIFT, ROLL, PITCH, YAW | yes | 141 | 308 | F119-PW-1 | BETA |
| F450/F450 | F450 | LIFT, DRAG, SIDE, ROLL, PITCH, YAW | yes | 0 | 60 | DJI_E305 | ALPHA |
| F4N/F4N-jsbsim | F4N | LIFT, DRAG, SIDE, ROLL, PITCH, YAW | yes | 25 | 224 | J79-GE-11A | ALPHA |
| F4N/F4N | F4N | LIFT, DRAG, SIDE, ROLL, PITCH, YAW | yes | 25 | 224 | J79-GE-11A | ALPHA |
| F80C/F80C | F80C | DRAG, SIDE, LIFT, ROLL, PITCH, YAW | yes | 23 | 112 | J33-A-35 | BETA |
| fokker100/fokker100 | Fokker-100 | DRAG, SIDE, LIFT, ROLL, PITCH, YAW | yes | 132 | 112 | Tay-620 | ALPHA |
| fokker100/fokker70 | Fokker 70 | DRAG, SIDE, LIFT, ROLL, PITCH, YAW | yes | 66 | 112 | Tay-620 | BETA |
| fokker100/xf100 | Fokker-100 | DRAG, SIDE, LIFT, ROLL, PITCH, YAW | yes | 66 | 112 | BR-725 | ALPHA |
| fokker50/fokker50 | fokker50 | DRAG, SIDE, LIFT, ROLL, PITCH, YAW | yes | 92 | 250 | PW125BX | BETA |
| global5000/global5000 | global5000 | LIFT, DRAG, SIDE, ROLL, PITCH, YAW | yes | 47 | 112 | BR710 | ALPHA |
| J246/J246 | Jupiter-246 - Lunar Crew Launch Vehicle Configuration | DRAG, SIDE, LIFT | no | 38 | 0 | RL10, SRB, SSME | ALPHA |
| J3Cub/J3Cub | J3Cub | LIFT, DRAG, SIDE, PITCH, ROLL, YAW | yes | 136 | 56 | Continental A-65-8 | ALPHA |
| L17/L17 | Navion | DRAG, SIDE, LIFT, ROLL, PITCH, YAW | yes | 22 | 56 | engIO470D | BETA |
| L410/L410 | Czech Republic LET 410 Light Twin | DRAG, SIDE, LIFT, ROLL, PITCH, YAW | yes | 22 | 559 | engtm601 | BETA |
| MD11/MD11 | MD11 | DRAG, SIDE, LIFT, ROLL, PITCH, YAW | yes | 22 | 104 | CF6-80C2 | BETA |
| minisgs/minisgs | sgstest | DRAG, SIDE, LIFT, ROLL, PITCH, YAW | yes | 76 | 0 | — | BETA |
| mk82/mk82 | MK-82 | DRAG, SIDE, LIFT, ROLL, PITCH, YAW | yes | 793 | 0 | — | BETA |
| OV10/OV10 | OV10 Bronco | DRAG, SIDE, LIFT, ROLL, PITCH, YAW | yes | 25 | 96 | T76 | BETA |
| p51d/p51d | P-51D (JSBSim) | DRAG, SIDE, LIFT, ROLL, PITCH, YAW | yes | 270 | 68 | Packard-V-1650-7 | BETA |
| pa28/pa28 | PA28-180 | DRAG, SIDE, LIFT, ROLL, PITCH, YAW | yes | 89 | 255 | engIO360C | BETA |
| paraglider/paraglider | paraglider | DRAG, SIDE, LIFT, ROLL, PITCH, YAW | yes | 237 | 83 | Polini_THOR80 | BETA |
| pc7/pc7 | PC-7 | LIFT, DRAG, SIDE, PITCH, ROLL, YAW | yes | 92 | 611 | PT6A | ALPHA |
| pogo-jsbsim/pogo-jsbsim | Pogo | LIFT, DRAG, SIDE, ROLL, PITCH, YAW | yes | 33 | 212 | YT40-A-16 | ALPHA |
| Pterosaur/Pterosaur | Pterosaur | LIFT, DRAG, SIDE, PITCH, ROLL, YAW | yes | 57 | 0 | dummy | ALPHA |
| SGS/SGS | sgstest | DRAG, SIDE, LIFT, ROLL, PITCH, YAW | yes | 70 | 0 | — | BETA |
| sgs126/sgs126 | sgs126 | DRAG, SIDE, LIFT, ROLL, PITCH, YAW | yes | 22 | 0 | — | BETA |
| sgs233/sgs233 | sgs233 | DRAG, SIDE, LIFT, ROLL, PITCH, YAW | yes | 14 | 0 | — | BETA |
| Short_S23/Short_S23 | Short S.23 | LIFT, DRAG, SIDE, ROLL, PITCH, YAW | yes | 918 | 129 | eng_PegasusXc | BETA |
| Shuttle/Shuttle | Space Shuttle | DRAG, SIDE, LIFT, ROLL, PITCH, YAW | yes | 81 | 0 | — | BETA |
| Submarine_Scout/Submarine_Scout | SubmarineScout | DRAG, SIDE, LIFT, ROLL, PITCH, YAW | yes | 222 | 24 | eng_RRhawk | ALPHA |
| T37/T37 | T37 | DRAG, SIDE, LIFT, ROLL, PITCH, YAW | yes | 48 | 112 | J69-T25 | BETA |
| T38/T38 | T38 | DRAG, SIDE, LIFT, ROLL, PITCH, YAW | yes | 26 | 224 | J85-GE-5 | BETA |
| t6texan2/t6texan2 | T62 | DRAG, SIDE, LIFT, ROLL, PITCH, YAW | yes | 90 | 96 | PT6A-68 | BETA |
| weather-balloon/weather-balloon | Weather Balloon | DRAG, ROLL, PITCH, YAW | no | 9 | 0 | — | ALPHA |
| wrightFlyer1903/wrightFlyer1903 | wrightFlyer1903 | LIFT, DRAG, SIDE, ROLL, PITCH, YAW | yes | 667 | 25 | wright1903_engine | ALPHA |
| wrightFlyer1903/wrightFlyer1905 | wrightFlyer1903 | LIFT, DRAG, SIDE, ROLL, PITCH, YAW | yes | 665 | 25 | wright1905_engine | ALPHA |
| X15/X15 | North American X-15 | DRAG, SIDE, LIFT, ROLL, PITCH, YAW | yes | 146 | 0 | XLR99 | BETA |
| x24b/x24b | X-24B | DRAG, SIDE, LIFT, ROLL, PITCH, YAW | yes | 3 | 0 | XLR99 | BETA |
| XB-70/XB-70 | XB-70 | DRAG, SIDE, LIFT, ROLL, PITCH, YAW | yes | 22 | 366 | YJ93-GE-3 | BETA |
| ZLT-NT/ZLT-NT | NT07 | DRAG, SIDE, LIFT, ROLL, PITCH, YAW | yes | 1079 | 338 | electric147kW, engIO360C | BETA |
