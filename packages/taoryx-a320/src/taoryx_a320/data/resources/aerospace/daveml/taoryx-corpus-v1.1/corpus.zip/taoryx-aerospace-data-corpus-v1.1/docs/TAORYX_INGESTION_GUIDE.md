# Taoryx ingestion guide

## Qualified packages

Load the `.txair` packages under `qualified-models/*/` as regression baselines. Preserve each manifest, checksum
ledger, source provenance, and validation output alongside the runtime model.

## JSBSim candidates

For a new vehicle family:

1. Select a row from `consolidated/model-catalog.csv`.
2. Read its raw primary XML and every referenced engine, thruster, and external system file.
3. Use the matching normalized directory to inspect quantities, functions, expression trees, and long-form tables.
4. Establish an explicit SI/frame contract before compiling a Taoryx evaluator.
5. Add trim, pointwise, dynamic, and trajectory evidence before promoting the model into `qualified-models/`.

The normalized files are:

```text
model.json
quantities.csv
aerodynamic-functions.csv
aerodynamic-expressions.json
aerodynamic-tables.csv
propulsion-tables.csv
table-index.json
```

## A320 pseudo-6DOF fusion

Do not add the OpenAP and JSBSim drag or thrust models together. Recommended ownership is:

- OpenAP: drag, configured drag, thrust, fuel flow, operational mass envelope.
- JSBSim: approximate lift curve shape, side force, moments, damping, control effects, and surrogate inertia.
- Taoryx: source arbitration, actuator dynamics, stabilization, flight-plan controller, and qualification tests.

Record every synthetic inertia schedule, control lag, limit, and stabilizer gain in an assumptions file.

## Quality levels

- `qualified-models/`: executable baselines with recorded acceptance evidence.
- JSBSim `PRODUCTION/BETA/ALPHA`: upstream release labels, not Taoryx qualification grades.
- Presence of six axes means structural coverage only; it is not evidence of manufacturer or flight-test fidelity.
