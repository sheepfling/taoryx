
# Qualification and trust levels

## Qualified Taoryx baselines

The F-16 S-119, A320 OpenAP, NESC two-stage rocket, and HL-20 packages include explicit acceptance evidence and compiled `.txair` artifacts. Read each model card and quality report before selecting tolerances.

## Normalized source-corpus models

The 64 JSBSim configurations were parsed successfully and exported without parser failures. Their raw and normalized data are useful for engineering surrogates, pseudo-6DOF models, model-family coverage, and comparative testing. They have not all received independent trajectory or handling-quality validation.

## Source, estimate, and policy separation

Do not merge overlapping source contributions without a written binding contract. In particular, the A320 OpenAP and JSBSim models overlap in drag and propulsion. A fused pseudo-6DOF model should use one source per force/moment responsibility and label any inertia or actuator schedule that is estimated.
