
from __future__ import annotations

import csv
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_catalog_and_qualified_counts() -> None:
    with (ROOT / 'consolidated/model-catalog.csv').open(newline='', encoding='utf-8') as f:
        catalog = list(csv.DictReader(f))
    with (ROOT / 'consolidated/qualified-model-index.csv').open(newline='', encoding='utf-8') as f:
        qualified = list(csv.DictReader(f))
    assert len(catalog) == 64
    assert len(qualified) == 4
    ####


def test_focus_vehicle_paths_exist() -> None:
    paths = json.loads((ROOT / 'consolidated/vehicle-paths.json').read_text(encoding='utf-8'))
    for vehicle in ('f16', 'a320', 'hl20'):
        for rel in paths[vehicle].values():
            assert (ROOT / rel).exists(), (vehicle, rel)
        ####
    ####
