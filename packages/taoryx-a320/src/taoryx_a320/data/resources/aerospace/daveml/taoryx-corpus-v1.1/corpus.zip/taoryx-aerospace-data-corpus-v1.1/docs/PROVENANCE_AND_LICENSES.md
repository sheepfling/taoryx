# Provenance and licenses

This corpus is a collection of separately sourced artifacts. It does not place all content under one new license.

- JSBSim source data is pinned to tag `v1.3.1`, commit `3b25f25e49b42d0489c04ac805674fc1450ca579`.
  Its `COPYING` file is included under `source-corpora/jsbsim-1.3.1/raw/`.
- OpenAP A320 source records include their original `source/openap/data/LICENSE` file.
- F-16 and HL-20 packages retain source descriptions, references, hashes, and provenance records in their model
  directories and evidence archives.
- NASA/NESC rocket material retains its source provenance and validation caveats.
- The Taoryx conversion tooling and release archives retain their own license and release metadata.

Before redistributing a derived model, preserve the source notices and verify that the intended distribution is
compatible with every contributing source. This document is an inventory note, not legal advice.
