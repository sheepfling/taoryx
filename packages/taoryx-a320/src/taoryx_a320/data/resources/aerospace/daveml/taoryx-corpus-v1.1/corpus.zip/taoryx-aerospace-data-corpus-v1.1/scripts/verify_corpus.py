
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import sys
import zipfile
from pathlib import Path


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        while chunk := f.read(1024 * 1024):
            h.update(chunk)
    return h.hexdigest()


def fail(message: str) -> None:
    raise RuntimeError(message)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, default=Path('.'))
    parser.add_argument('--json', type=Path)
    args = parser.parse_args()
    root = args.root.resolve()
    report: dict[str, object] = {'root': str(root), 'checks': [], 'passed': False}
    checks: list[dict[str, object]] = report['checks']  # type: ignore[assignment]

    ledger = root / 'checksums.sha256'
    if not ledger.is_file():
        fail('missing checksums.sha256')
    ledger_rows = []
    for line in ledger.read_text(encoding='utf-8').splitlines():
        if not line.strip():
            continue
        digest, rel = line.split('  ', 1)
        ledger_rows.append((digest, rel))
    for expected, rel in ledger_rows:
        path = root / rel
        if not path.is_file():
            fail(f'missing file: {rel}')
        actual = sha256_file(path)
        if actual != expected:
            fail(f'hash mismatch: {rel}')
    checks.append({'name': 'sha256-ledger', 'passed': True, 'files': len(ledger_rows)})

    with (root / 'consolidated/model-catalog.csv').open(newline='', encoding='utf-8') as f:
        catalog = list(csv.DictReader(f))
    if len(catalog) != 64:
        fail(f'expected 64 catalog configurations, found {len(catalog)}')
    normalized_root = root / 'source-corpora/jsbsim-1.3.1/normalized-models'
    for row in catalog:
        model_dir = normalized_root / row['model_key']
        required = [
            'model.json', 'quantities.csv', 'aerodynamic-functions.csv',
            'aerodynamic-expressions.json', 'aerodynamic-tables.csv',
            'propulsion-tables.csv', 'table-index.json',
        ]
        missing = [name for name in required if not (model_dir / name).is_file()]
        if missing:
            fail(f"{row['model_key']} missing normalized files: {missing}")
    checks.append({'name': 'jsbsim-normalized-models', 'passed': True, 'models': 64})

    raw_root = root / 'source-corpora/jsbsim-1.3.1/raw'
    for rel in ['COPYING', 'FILE_INVENTORY.tsv', 'FILE_SHA256SUMS', 'aircraft', 'engine']:
        if not (raw_root / rel).exists():
            fail(f'missing raw JSBSim content: {rel}')
    checks.append({'name': 'jsbsim-raw-source', 'passed': True})

    with (root / 'consolidated/qualified-model-index.csv').open(newline='', encoding='utf-8') as f:
        qualified = list(csv.DictReader(f))
    if len(qualified) != 4:
        fail(f'expected 4 qualified models, found {len(qualified)}')
    for row in qualified:
        package = root / row['runtime_package']
        if not package.is_file():
            fail(f"missing qualified runtime: {row['runtime_package']}")
        with zipfile.ZipFile(package) as zf:
            bad = zf.testzip()
            if bad:
                fail(f'CRC failure in {package.name}: {bad}')
            for member in zf.namelist():
                pp = Path(member)
                if pp.is_absolute() or '..' in pp.parts:
                    fail(f'unsafe archive member in {package.name}: {member}')
    checks.append({'name': 'qualified-txair-packages', 'passed': True, 'models': 4})

    path_map = json.loads((root / 'consolidated/vehicle-paths.json').read_text(encoding='utf-8'))
    for vehicle in ['f16', 'a320', 'hl20']:
        if vehicle not in path_map:
            fail(f'missing focus vehicle map: {vehicle}')
        for name, rel in path_map[vehicle].items():
            if not (root / rel).exists():
                fail(f'missing {vehicle} path {name}: {rel}')
    checks.append({'name': 'focus-vehicle-paths', 'passed': True, 'vehicles': 3})

    manifest = json.loads((root / 'corpus-manifest.json').read_text(encoding='utf-8'))
    if manifest['counts']['jsbsim_models'] != 64 or manifest['counts']['qualified_models'] != 4:
        fail('manifest model counts are inconsistent')
    checks.append({'name': 'corpus-manifest', 'passed': True})

    report['passed'] = True
    if args.json:
        args.json.parent.mkdir(parents=True, exist_ok=True)
        args.json.write_text(json.dumps(report, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f'CORPUS VERIFICATION FAILED: {exc}', file=sys.stderr)
        raise SystemExit(1)
