
# HL-20 data map

`qualified-models/hl20-mod-k/` contains the complete HL-20 collection in this corpus:

- exact pinned Mod K DAVE-ML aerodynamic source;
- normalized source IR, variables, functions, expressions, breakpoints, and all table points;
- embedded check cases and 24/24 acceptance evidence;
- fixed mass/inertia binding with separate provenance;
- control-increment and clean-aerodynamic inspection tables;
- glide trim and rigid-body hold trajectory;
- compiled unpowered 6-DOF `.txair` package.

The model is an unpowered, fixed-mass baseline. The corpus does not represent propulsion, reaction controls, actuator dynamics, landing contact, or flexible-body behavior as part of the qualified HL-20 package.
