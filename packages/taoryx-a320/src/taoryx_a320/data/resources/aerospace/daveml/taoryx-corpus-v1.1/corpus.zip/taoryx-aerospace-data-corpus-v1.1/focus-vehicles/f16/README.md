
# F-16 data map

This corpus carries two distinct F-16 sources. They must remain separate in provenance and qualification:

1. `qualified-models/f16-s119/` is the qualified Taoryx S-119 baseline: normalized DAVE-ML aerodynamics, propulsion, inertia, control binding, trim, trajectory evidence, and the compiled `.txair` package.
2. `source-corpora/jsbsim-1.3.1/raw/aircraft/f16/` is the JSBSim F-16 approximation, with its engine and thruster files under `raw/engine/`.
3. `source-corpora/jsbsim-1.3.1/normalized-models/f16/f16/` is the loss-preserving normalized export of the JSBSim model.
4. `releases/taoryx-f16-mod-k-aero-v0.6.zip` retains the earlier aerodynamic-only acceptance evidence.

The qualified S-119 baseline is the primary Taoryx test model. The JSBSim model is a separate surrogate/reference corpus model, not a replacement for the qualified package.
