# Consolidated data dictionary

## `model-catalog.csv`

One row per JSBSim configuration. Includes source path/hash, declared aerodynamic axes, table counts, propulsion
counts, engine and thruster dependencies, external sections, and parser issues.

## `all-aerodynamic-functions.csv`

One row per aerodynamic function. `model_key` and `axis` identify ownership; `table_ids` links to the long-form
point file.

## `all-aerodynamic-table-points.csv`

Long-form representation of every decoded aerodynamic lookup point. Coordinate columns retain row, column, table,
and additional dimensions. `value` is the dependent value in source semantics.

## `all-propulsion-table-points.csv`

Same long-form representation for engine and thruster tables.

## `all-quantities.csv`

Normalized scalar quantities from metrics, mass balance, propulsion, controls, and other source sections. Raw
values and units are preserved; `si_value` and `si_unit` are populated where a supported conversion is known.

Always trace a row back through `source_path` and `model_key` before using it as a runtime model parameter.
